# app/bookstack.py - COMPLETO PER IL TUO LOGBOOK PRESSA
import httpx
import logging
from datetime import datetime
from typing import Optional, Dict, Any
from config import settings

logger = logging.getLogger(__name__)

DAYS_IT = {
    0: "Lunedì", 1: "Martedì", 2: "Mercoledì", 3: "Giovedì",
    4: "Venerdì", 5: "Sabato", 6: "Domenica"
}

MONTHS_IT = {
    1: "Gennaio", 2: "Febbraio", 3: "Marzo", 4: "Aprile",
    5: "Maggio", 6: "Giugno", 7: "Luglio", 8: "Agosto",
    9: "Settembre", 10: "Ottobre", 11: "Novembre", 12: "Dicembre"
}


class BookStackClient:
    def __init__(self):
        self.base_url = settings.BOOKSTACK_URL.rstrip('/')
        self.token = settings.BOOKSTACK_TOKEN
        self.headers = {
            'Authorization': f'Token {self.token}',
            'Content-Type': 'application/json'
        }
        self.client = httpx.AsyncClient(headers=self.headers, timeout=30.0)

    async def close(self):
        await self.client.aclose()

    def get_today_page_name(self) -> str:
        """Martedì 07-04-2026"""
        dt = datetime.now()
        day_name = DAYS_IT[dt.weekday()]
        return f"{day_name} {dt.strftime('%d-%m-%Y')}"

    def get_month_chapter_name(self) -> str:
        """Aprile 2026"""
        dt = datetime.now()
        return f"{MONTHS_IT[dt.month]} {dt.year}"

    async def find_book_by_name(self, name_contains: str) -> Optional[Dict]:
        """Trova book per nome"""
        try:
            resp = await self.client.get(f"{self.base_url}/api/books?count=100")
            resp.raise_for_status()
            books = resp.json()['data']
            
            for book in books:
                if name_contains.lower() in book['name'].lower():
                    logger.info(f"Book trovato: {book['name']} (ID: {book['id']})")
                    return book
            logger.warning(f"Book '{name_contains}' non trovato")
            return None
        except Exception as e:
            logger.error(f"Errore ricerca book: {e}")
            return None

    async def find_chapter_in_book(self, book_id: int, name_contains: str) -> Optional[Dict]:
        """Trova chapter nel book"""
        try:
            resp = await self.client.get(f"{self.base_url}/api/books/{book_id}?include=chapters")
            resp.raise_for_status()
            book = resp.json()
            
            for chapter in book.get('chapters', []):
                if name_contains.lower() in chapter['name'].lower():
                    logger.info(f"Chapter trovato: {chapter['name']} (ID: {chapter['id']})")
                    return chapter
            logger.warning(f"Chapter '{name_contains}' non trovato nel book {book_id}")
            return None
        except Exception as e:
            logger.error(f"Errore ricerca chapter: {e}")
            return None

    async def find_page_in_chapter(self, chapter_id: int, exact_name: str) -> Optional[Dict]:
        """Trova pagina per nome esatto nel chapter"""
        try:
            resp = await self.client.get(f"{self.base_url}/api/chapters/{chapter_id}?include=pages")
            resp.raise_for_status()
            chapter = resp.json()
            
            for page in chapter.get('pages', []):
                if page['name'] == exact_name:
                    logger.info(f"Pagina trovata: {page['name']} (ID: {page['id']})")
                    return page
            logger.info(f"Pagina '{exact_name}' non trovata nel chapter {chapter_id}")
            return None
        except Exception as e:
            logger.error(f"Errore ricerca pagina: {e}")
            return None

    async def create_page_in_chapter(self, chapter_id: int, name: str, markdown: str) -> Optional[int]:
        """Crea nuova pagina"""
        try:
            data = {
                "name": name,
                "chapter_id": chapter_id,
                "markdown": markdown
            }
            resp = await self.client.post(f"{self.base_url}/api/pages", json=data)
            resp.raise_for_status()
            result = resp.json()
            page_id = result['id']
            logger.info(f"Pagina creata: {name} (ID: {page_id})")
            return page_id
        except Exception as e:
            logger.error(f"Errore creazione pagina: {e}")
            return None

    async def update_page(self, page_id: int, markdown: str) -> bool:
        """Aggiorna markdown pagina esistente"""
        try:
            data = {"markdown": markdown}
            resp = await self.client.put(f"{self.base_url}/api/pages/{page_id}", json=data)
            resp.raise_for_status()
            logger.info(f"Pagina {page_id} aggiornata")
            return True
        except Exception as e:
            logger.error(f"Errore update pagina {page_id}: {e}")
            return False

    def format_log_entry(self, ticket_code: str, payload: Any) -> str:
        """Formato Markdown per nuova voce"""
        now = datetime.now().strftime("%H:%M")
        return f"""
## {now} - {ticket_code}

**Reparto**: {payload.department or 'N/D'}  
**Asset**: {payload.asset or 'N/D'}  
**Priorità**: {payload.priority.upper() if payload.priority else 'N/D'}  
**Tipo**: {payload.issue_type or 'N/D'}  
**Luogo**: {payload.location or 'N/D'}  
**Descrizione**: {payload.description}

---
"""

    async def create_log_page(self, ticket_code: str, payload: Any) -> Optional[int]:
        """Main function: crea/aggiorna pagina giornaliera"""
        page_name = self.get_today_page_name()
        month_name = self.get_month_chapter_name()
        
        # 1. Trova book Pressa
        pressa_book = await self.find_book_by_name("Pressa")
        if not pressa_book:
            logger.error("Book 'Pressa' non trovato!")
            return None
        book_id = pressa_book['id']
        
        # 2. Trova chapter Aprile 2026
        month_chapter = await self.find_chapter_in_book(book_id, month_name)
        if not month_chapter:
            logger.error(f"Chapter '{month_name}' non trovato!")
            return None
        chapter_id = month_chapter['id']
        
        # 3. Trova pagina odierna
        today_page = await self.find_page_in_chapter(chapter_id, page_name)
        
        if today_page:
            # 4. Aggiorna pagina esistente
            page_id = today_page['id']
            resp = await self.client.get(f"{self.base_url}/api/pages/{page_id}")
            resp.raise_for_status()
            current_data = resp.json()
            current_markdown = current_data.get('markdown', '')
            
            new_entry = self.format_log_entry(ticket_code, payload)
            new_markdown = current_markdown.rstrip() + "\n\n" + new_entry
            
            if await self.update_page(page_id, new_markdown):
                logger.info(f"Pagina {page_name} aggiornata con {ticket_code}")
                return page_id
        else:
            # 5. Crea nuova pagina
            title = f"# Logbook Pressa - {page_name}\n\n"
            new_entry = self.format_log_entry(ticket_code, payload)
            new_markdown = title + new_entry
            
            page_id = await self.create_page_in_chapter(chapter_id, page_name, new_markdown)
            if page_id:
                logger.info(f"Pagina {page_name} creata con {ticket_code}")
                return page_id
        
        return None


# Inizializza globalmente
bookstack = BookStackClient()