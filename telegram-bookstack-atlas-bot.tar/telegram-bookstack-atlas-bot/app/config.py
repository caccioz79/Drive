import os

class Settings:
    TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
    TELEGRAM_WEBHOOK_SECRET = os.getenv("TELEGRAM_WEBHOOK_SECRET", "")
    APP_BASE_URL = os.getenv("APP_BASE_URL", "")
    ADMIN_CHAT_ID = int(os.getenv("ADMIN_CHAT_ID", "0") or 0)
    ACCESS_PASSWORD = os.getenv("ACCESS_PASSWORD", "")

    BOOKSTACK_URL = os.getenv("BOOKSTACK_URL", "").rstrip("/")
    BOOKSTACK_TOKEN_ID = os.getenv("BOOKSTACK_TOKEN_ID", "")
    BOOKSTACK_TOKEN_SECRET = os.getenv("BOOKSTACK_TOKEN_SECRET", "")
    BOOKSTACK_BOOK_ID = int(os.getenv("BOOKSTACK_BOOK_ID", "0") or 0)
    BOOKSTACK_CHAPTER_ID = int(os.getenv("BOOKSTACK_CHAPTER_ID", "0") or 0)

    ATLAS_URL = os.getenv("ATLAS_URL", "").rstrip("/")
    ATLAS_USERNAME = os.getenv("ATLAS_USERNAME", "")
    ATLAS_PASSWORD = os.getenv("ATLAS_PASSWORD", "")
    ATLAS_API_TOKEN = os.getenv("ATLAS_API_TOKEN", "")

    DB_PATH = os.getenv("DB_PATH", "/app/data/tickets.db")

settings = Settings()
