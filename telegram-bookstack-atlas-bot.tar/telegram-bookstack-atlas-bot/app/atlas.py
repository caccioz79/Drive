import httpx
from config import settings

class AtlasClient:
    def __init__(self):
        self.base = settings.ATLAS_URL.rstrip("/")
        self.token = settings.ATLAS_API_TOKEN

    def create_work_request(self, ticket_code: str, payload) -> str | None:
        if not self.base or not self.token:
            return "ERRORE: ATLAS_URL o ATLAS_API_TOKEN mancanti"

        headers = {
            "Accept": "application/json",
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }

        body = {
            "title": f"{ticket_code} - {payload.issue_type}",
            "primaryUser": None,
            "location": payload.location,
            "team": None,
            "asset": payload.asset,
            "assignedTo": [],
            "category": None,
            "image": None,
            "files": [],
        }

        if payload.description:
            body["description"] = payload.description
        if payload.department:
            body["team"] = payload.department  # meccanica/elettrica

        try:
            with httpx.Client(timeout=20) as client:
                r = client.post(f"{self.base}/requests", headers=headers, json=body)
                r.raise_for_status()
                data = r.json()
                return data.get("customId") or str(data.get("id"))
        except Exception as e:
            return f"ERRORE ATLAS: {str(e)}"