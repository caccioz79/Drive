import os
import sqlite3
from contextlib import contextmanager
from config import settings

os.makedirs(os.path.dirname(settings.DB_PATH), exist_ok=True)

@contextmanager
def get_conn():
    conn = sqlite3.connect(settings.DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def init_db():
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                telegram_user_id INTEGER PRIMARY KEY,
                username TEXT,
                full_name TEXT,
                role TEXT DEFAULT 'pending',
                approved INTEGER DEFAULT 0,
                password_ok INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE,
                telegram_user_id INTEGER,
                full_name TEXT,
                department TEXT,
                issue_type TEXT,
                location TEXT,
                asset TEXT,
                priority TEXT,
                description TEXT,
                photo_url TEXT,
                status TEXT DEFAULT 'open',
                bookstack_page_id INTEGER,
                atlas_request_id TEXT,
                atlas_work_order_id TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (telegram_user_id) REFERENCES users(telegram_user_id)
            )
        """)

def upsert_user(telegram_user_id: int, username: str | None, full_name: str):
    with get_conn() as conn:
        conn.execute("""
            INSERT INTO users (telegram_user_id, username, full_name)
            VALUES (?, ?, ?)
            ON CONFLICT(telegram_user_id) DO UPDATE SET
                username=excluded.username,
                full_name=excluded.full_name
        """, (telegram_user_id, username, full_name))

def set_password_ok(telegram_user_id: int):
    with get_conn() as conn:
        conn.execute("UPDATE users SET password_ok=1 WHERE telegram_user_id=?", (telegram_user_id,))

def approve_user(telegram_user_id: int, role: str = "operatore"):
    with get_conn() as conn:
        conn.execute("UPDATE users SET approved=1, role=? WHERE telegram_user_id=?", (role, telegram_user_id))

def get_user(telegram_user_id: int):
    with get_conn() as conn:
        cur = conn.execute("SELECT * FROM users WHERE telegram_user_id=?", (telegram_user_id,))
        return cur.fetchone()

def next_ticket_code() -> str:
    with get_conn() as conn:
        cur = conn.execute("SELECT COUNT(*) AS c FROM tickets")
        n = cur.fetchone()["c"] + 1
        return f"G-2026-{n:04d}"

def create_ticket(data):
    code = next_ticket_code()
    with get_conn() as conn:
        cur = conn.execute("""
            INSERT INTO tickets (
                code, telegram_user_id, full_name, department, issue_type, location,
                asset, priority, description, photo_url
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            code, data.telegram_user_id, data.full_name, data.department, data.issue_type,
            data.location, data.asset, data.priority, data.description, data.photo_url
        ))
        return cur.lastrowid, code

def link_bookstack(ticket_id: int, page_id: int):
    with get_conn() as conn:
        conn.execute("UPDATE tickets SET bookstack_page_id=? WHERE id=?", (page_id, ticket_id))

def link_atlas_request(ticket_id: int, request_id: str):
    with get_conn() as conn:
        conn.execute("UPDATE tickets SET atlas_request_id=? WHERE id=?", (request_id, ticket_id))
