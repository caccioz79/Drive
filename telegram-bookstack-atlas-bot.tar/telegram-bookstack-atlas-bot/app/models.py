from dataclasses import dataclass
from datetime import datetime

@dataclass
class TicketPayload:
    telegram_user_id: int
    full_name: str
    department: str
    issue_type: str
    location: str
    asset: str
    priority: str
    description: str
    photo_url: str | None = None
    created_at: str = datetime.utcnow().isoformat()
