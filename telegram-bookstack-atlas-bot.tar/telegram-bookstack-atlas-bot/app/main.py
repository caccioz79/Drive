import logging
import os
import re
from datetime import datetime

import httpx
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
)

load_dotenv()

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("telegram-maintenance-bot")

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
BOOKSTACK_URL = os.getenv("BOOKSTACK_URL", "").rstrip("/")
BOOKSTACK_TOKEN_ID = os.getenv("BOOKSTACK_TOKEN_ID", "").strip()
BOOKSTACK_TOKEN_SECRET = os.getenv("BOOKSTACK_TOKEN_SECRET", "").strip()
BOOKSTACK_BOOK_ID = os.getenv("BOOKSTACK_BOOK_ID", "").strip()

ASK_GUASTO = 1

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN mancante nel file .env")

if not BOOKSTACK_URL:
    raise RuntimeError("BOOKSTACK_URL mancante nel file .env")

if not BOOKSTACK_TOKEN_ID or not BOOKSTACK_TOKEN_SECRET:
    raise RuntimeError("BOOKSTACK_TOKEN_ID o BOOKSTACK_TOKEN_SECRET mancanti nel file .env")

if not BOOKSTACK_BOOK_ID:
    raise RuntimeError("BOOKSTACK_BOOK_ID mancante nel file .env")


def bookstack_headers() -> dict:
    return {
        "Authorization": f"Token {BOOKSTACK_TOKEN_ID}:{BOOKSTACK_TOKEN_SECRET}",
        "Content-Type": "application/json",
    }


def italian_day_name(dt: datetime) -> str:
    days = {
        "Monday": "Lunedì",
        "Tuesday": "Martedì",
        "Wednesday": "Mercoledì",
        "Thursday": "Giovedì",
        "Friday": "Venerdì",
        "Saturday": "Sabato",
        "Sunday": "Domenica",
    }
    return days[dt.strftime("%A")]


def italian_month_name(dt: datetime) -> str:
    months = {
        1: "Gennaio",
        2: "Febbraio",
        3: "Marzo",
        4: "Aprile",
        5: "Maggio",
        6: "Giugno",
        7: "Luglio",
        8: "Agosto",
        9: "Settembre",
        10: "Ottobre",
        11: "Novembre",
        12: "Dicembre",
    }
    return months[dt.month]


def current_chapter_name(dt: datetime | None = None) -> str:
    if dt is None:
        dt = datetime.now()
    return f"{italian_month_name(dt)} {dt.year}"


def today_page_name(dt: datetime | None = None) -> str:
    if dt is None:
        dt = datetime.now()
    return f"Data: {italian_day_name(dt)} {dt.strftime('%d-%m-%Y')}"


def get_current_turno(dt: datetime | None = None) -> str:
    if dt is None:
        dt = datetime.now()

    hour = dt.hour

    if 4 <= hour < 12:
        return "Mattina"
    if 12 <= hour < 20:
        return "Pomeriggio"
    return "Notte"


async def get_chapters() -> tuple[bool, list | str]:
    url = f"{BOOKSTACK_URL}/api/chapters"

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(url, headers=bookstack_headers())

        if response.status_code != 200:
            return False, f"Errore lettura capitoli: {response.status_code} - {response.text[:300]}"

        data = response.json()
        return True, data.get("data", [])
    except Exception as exc:
        logger.exception("Errore lettura capitoli")
        return False, f"Eccezione lettura capitoli: {exc}"


async def get_chapter_detail(chapter_id: int) -> tuple[bool, dict | str]:
    url = f"{BOOKSTACK_URL}/api/chapters/{chapter_id}"

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(url, headers=bookstack_headers())

        if response.status_code != 200:
            return False, f"Errore lettura dettaglio capitolo {chapter_id}: {response.status_code} - {response.text[:300]}"

        return True, response.json()
    except Exception as exc:
        logger.exception("Errore lettura dettaglio capitolo")
        return False, f"Eccezione lettura dettaglio capitolo: {exc}"


async def find_today_page() -> tuple[bool, dict | str]:
    target_chapter = current_chapter_name()
    target_page = today_page_name()

    ok_chapters, chapters_data = await get_chapters()
    if not ok_chapters:
        return False, str(chapters_data)

    selected_chapter = None
    for chapter in chapters_data:
        if (
            chapter.get("book_id") == int(BOOKSTACK_BOOK_ID)
            and chapter.get("name", "").strip() == target_chapter
        ):
            selected_chapter = chapter
            break

    if not selected_chapter:
        return False, f"Capitolo del mese non trovato: '{target_chapter}'"

    chapter_id = selected_chapter["id"]

    ok_detail, chapter_detail = await get_chapter_detail(chapter_id)
    if not ok_detail:
        return False, str(chapter_detail)

    pages = chapter_detail.get("pages", [])
    for page in pages:
        if page.get("name", "").strip() == target_page:
            page["chapter_id"] = chapter_id
            return True, page

    page_names = [p.get("name", "") for p in pages]
    preview = ", ".join(page_names[:15]) if page_names else "nessuna pagina trovata"

    return False, (
        f"Capitolo trovato ('{target_chapter}') ma pagina del giorno non trovata: "
        f"'{target_page}'. Pagine trovate: {preview}"
    )


async def get_page_markdown(page_id: int) -> tuple[bool, str]:
    url = f"{BOOKSTACK_URL}/api/pages/{page_id}"

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(url, headers=bookstack_headers())

        if response.status_code != 200:
            return False, f"Errore lettura pagina {page_id}: {response.status_code} - {response.text[:300]}"

        data = response.json()
        markdown = data.get("markdown")

        if markdown is None:
            return False, "La pagina non contiene markdown disponibile via API"

        return True, markdown
    except Exception as exc:
        logger.exception("Errore lettura markdown pagina")
        return False, f"Eccezione lettura markdown: {exc}"


async def update_page_markdown(page_id: int, page_name: str, chapter_id: int | None, new_markdown: str) -> tuple[bool, str]:
    url = f"{BOOKSTACK_URL}/api/pages/{page_id}"

    payload = {
        "name": page_name,
        "markdown": new_markdown,
    }

    if chapter_id:
        payload["chapter_id"] = chapter_id
    else:
        payload["book_id"] = int(BOOKSTACK_BOOK_ID)

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.put(url, headers=bookstack_headers(), json=payload)

        if response.status_code in (200, 202):
            return True, "Pagina aggiornata correttamente"

        return False, f"Errore aggiornamento pagina: {response.status_code} - {response.text[:500]}"
    except Exception as exc:
        logger.exception("Errore update pagina")
        return False, f"Eccezione update pagina: {exc}"


def build_event_block(update: Update, testo_guasto: str, dt: datetime | None = None) -> str:
    if dt is None:
        dt = datetime.now()

    ora = dt.strftime("%H:%M")
    user = update.effective_user
    nome_utente = user.full_name if user else "Utente sconosciuto"
    username = f"@{user.username}" if user and user.username else "nessuno"

    return (
        f"- [{ora}] Segnalazione guasto\n"
        f"  - Dettagli: {testo_guasto.strip()}\n"
        f"  - Fermo macchina: Sì / No (durata: ___ min)\n"
        f"  - Ricambi usati:\n"
        f"  - Elettricista/meccanico coinvolto: {nome_utente} {username}\n"
    )


def insert_event_in_turn_section(markdown: str, turno: str, event_block: str) -> tuple[bool, str]:
    pattern = (
        rf"(## Info turno\s*"
        rf"- Data: .*?\s*"
        rf"- Turno: {re.escape(turno)}\s*"
        rf".*?"
        rf"## Eventi principali\s*\n)"
        rf"(.*?)(\n## Segnalazioni ad Atlas)"
    )

    match = re.search(pattern, markdown, flags=re.DOTALL)
    if not match:
        return False, f"Sezione del turno '{turno}' non trovata nel markdown"

    header = match.group(1)
    body = match.group(2).rstrip()
    footer = match.group(3)

    if body:
        new_body = body + "\n" + event_block.rstrip() + "\n"
    else:
        new_body = event_block.rstrip() + "\n"

    new_section = header + new_body + footer
    new_markdown = markdown[:match.start()] + new_section + markdown[match.end():]

    return True, new_markdown


async def append_guasto_to_today_page(update: Update, testo_guasto: str) -> tuple[bool, str]:
    found, page_data = await find_today_page()
    if not found:
        return False, str(page_data)

    page_id = page_data["id"]
    page_name = page_data["name"]
    chapter_id = page_data.get("chapter_id")

    ok_markdown, current_markdown = await get_page_markdown(page_id)
    if not ok_markdown:
        return False, current_markdown

    turno = get_current_turno()
    event_block = build_event_block(update, testo_guasto)

    ok_insert, updated_markdown = insert_event_in_turn_section(
        current_markdown,
        turno,
        event_block,
    )
    if not ok_insert:
        return False, updated_markdown

    ok_update, message = await update_page_markdown(
        page_id=page_id,
        page_name=page_name,
        chapter_id=chapter_id,
        new_markdown=updated_markdown,
    )
    if not ok_update:
        return False, message

    return True, f"Guasto scritto nel turno '{turno}' della pagina '{page_name}' (ID {page_id})"


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = (
        "Bot manutenzione attivo.\n\n"
        "Comandi disponibili:\n"
        "/ping - verifica bot\n"
        "/guasto - inserisci una segnalazione guasto nel giorno corrente\n"
        "/annulla - annulla operazione corrente"
    )
    await update.message.reply_text(text)


async def ping_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    now = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    chapter_name = current_chapter_name()
    page_name = today_page_name()
    turno = get_current_turno()

    await update.message.reply_text(
        f"Pong ✅\nOra server: {now}\nCapitolo corrente: {chapter_name}\nPagina di oggi: {page_name}\nTurno corrente: {turno}"
    )


async def guasto_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    turno = get_current_turno()
    await update.message.reply_text(
        f"Scrivi la descrizione del guasto.\n\n"
        f"La segnalazione verrà inserita in 'Eventi principali' del turno: {turno}."
    )
    return ASK_GUASTO


async def guasto_receive(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    testo_guasto = (update.message.text or "").strip()

    if not testo_guasto:
        await update.message.reply_text("Testo vuoto. Riscrivi la segnalazione.")
        return ASK_GUASTO

    await update.message.reply_text("Sto aggiornando la sezione corretta su BookStack...")

    ok, message = await append_guasto_to_today_page(update, testo_guasto)

    if ok:
        await update.message.reply_text(f"OK ✅\n{message}")
    else:
        await update.message.reply_text(f"Errore ❌\n{message}")

    return ConversationHandler.END


async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("Operazione annullata.")
    return ConversationHandler.END


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.exception("Errore durante la gestione di un update", exc_info=context.error)


def main() -> None:
    logger.info("Avvio bot Telegram in polling...")

    application = Application.builder().token(BOT_TOKEN).build()

    conv_guasto = ConversationHandler(
        entry_points=[CommandHandler("guasto", guasto_start)],
        states={
            ASK_GUASTO: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, guasto_receive)
            ]
        },
        fallbacks=[CommandHandler("annulla", cancel_command)],
    )

    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("ping", ping_command))
    application.add_handler(CommandHandler("annulla", cancel_command))
    application.add_handler(conv_guasto)
    application.add_error_handler(error_handler)

    logger.info("Bot pronto. Avvio polling...")
    application.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()