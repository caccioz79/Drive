# Telegram → BookStack → Atlas CMMS

Progetto base per gestire:
- segnalazioni guasto/intervento via Telegram Bot
- scrittura automatica nel logbook BookStack
- apertura richiesta di lavoro in Atlas CMMS

## Flusso
1. L'operatore invia una segnalazione dal bot Telegram.
2. Il backend salva la segnalazione su SQLite.
3. Il backend aggiorna una pagina logbook su BookStack via API token.
4. Il backend prepara l'invio verso Atlas CMMS come Work Request.
5. Il bot conferma all'utente l'esito della registrazione.

## Stato del progetto
Questo progetto è uno scheletro funzionante lato struttura, database e integrazione BookStack.
La parte Atlas è predisposta come adapter, perché va collegata agli endpoint reali della tua installazione.

## Requisiti
- Docker e Docker Compose
- Token Telegram Bot
- BookStack con API token attivo
- URL della tua installazione Atlas CMMS

## Avvio rapido
1. Copia `.env.example` in `.env`
2. Compila le variabili
3. Avvia:
   docker compose up -d --build
4. Controlla i log:
   docker compose logs -f

## Note Atlas
Atlas CMMS documenta il flusso Work Request → Approve → Work Order.
Per questo conviene creare dal bot una Work Request, non un Work Order diretto.
