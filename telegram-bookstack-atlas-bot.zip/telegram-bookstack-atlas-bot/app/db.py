import sqlite3
import logging
from datetime import datetime
from typing import Optional

logger = logging.getLogger(__name__)

DB_PATH = "data/tickets.db"


def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        telegram_id INTEGER PRIMARY KEY,
        full_name TEXT,
        username TEXT,
        role TEXT DEFAULT 'utente',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE,
        telegram_user_id INTEGER,
        full_name TEXT,
        issue_type TEXT,
        priority TEXT,
        location TEXT,
        description TEXT,
        bookstack_page_id INTEGER,
        status TEXT DEFAULT 'open',
        turno TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
    """)

    cursor.execute("PRAGMA table_info(tickets)")
    ticket_columns = [col[1] for col in cursor.fetchall()]
    if "turno" not in ticket_columns:
        cursor.execute("ALTER TABLE tickets ADD COLUMN turno TEXT")
        logger.info("Aggiunta colonna turno")

    conn.commit()
    conn.close()
    logger.info("DB pronto")


def get_or_create_user(telegram_id: int, full_name: str, username: Optional[str] = None) -> int:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("SELECT telegram_id FROM users WHERE telegram_id = ?", (telegram_id,))
    exists = cursor.fetchone()

    if exists:
        cursor.execute(
            "UPDATE users SET full_name = ?, username = ? WHERE telegram_id = ?",
            (full_name, username, telegram_id),
        )
    else:
        cursor.execute(
            "INSERT INTO users (telegram_id, full_name, username) VALUES (?, ?, ?)",
            (telegram_id, full_name, username),
        )
        logger.info(f"Nuovo utente: {full_name}")

    conn.commit()
    conn.close()
    return telegram_id


def get_next_ticket_number() -> int:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    today = datetime.now().strftime("%Y%m%d")
    cursor.execute("SELECT COUNT(*) FROM tickets WHERE code LIKE ?", (f"TICKET-{today}%",))
    count = cursor.fetchone()[0] + 1
    conn.close()
    return count


def create_ticket(
    creator_id: int,
    type: str,
    priority: str,
    zone: str,
    description: str,
    turno: str,
    bookstack_page_id: int,
) -> str:
    ticket_id = f"TICKET-{datetime.now().strftime('%Y%m%d')}-{get_next_ticket_number():03d}"

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("SELECT full_name FROM users WHERE telegram_id = ?", (creator_id,))
    row = cursor.fetchone()
    full_name = row[0] if row else "Utente sconosciuto"

    cursor.execute(
        "INSERT INTO tickets (code, telegram_user_id, full_name, issue_type, priority, location, description, bookstack_page_id, status, turno) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', ?)",
        (ticket_id, creator_id, full_name, type, priority, zone, description, bookstack_page_id, turno),
    )

    conn.commit()
    conn.close()
    logger.info(f"Ticket {ticket_id} creato")
    return ticket_id


def get_user_role(telegram_id: int) -> str:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT role FROM users WHERE telegram_id = ?", (telegram_id,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else "utente"


def get_open_tickets(limit: int = 10) -> list:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT code, issue_type, priority, location, status, created_at FROM tickets WHERE status = 'open' ORDER BY created_at DESC LIMIT ?",
        (limit,),
    )
    results = cursor.fetchall()
    conn.close()
    return results