import logging
import os
import re
from datetime import datetime, timedelta

import httpx
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
)

from db import init_db, get_or_create_user, create_ticket, get_user_role, get_open_tickets

load_dotenv()

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("telegram-maintenance-bot")

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
BOOKSTACK_URL = os.getenv("BOOKSTACK_URL", "").rstrip("/")
BOOKSTACK_TOKEN_ID = os.getenv("BOOKSTACK_TOKEN_ID", "").strip()
BOOKSTACK_TOKEN_SECRET = os.getenv("BOOKSTACK_TOKEN_SECRET", "").strip()

ZONE_TO_BOOK_ID = {
    "Zona Essiccatoio": 2660,
    "Zona Verde": 3230,
    "Zona Cippatore": 3515,
    "Zona Pressa Dieffenbacher": 2945,
    "Zona scarico Dieffenbacher": 3800,
    "Zona Pressa Contiroll": 4085,
    "Zona scarico Contiroll": 4370,
    "Zona Giben": 4655,
    "Zona Melaminico 2": 4940,
    "Zona Melaminico 3": 5225,
    "Altro": 2660,
    "Zona Minibunker": 2660,
    "Zona Pulitori 1": 2660,
    "Zona Pulitori 2": 2660,
    "Zona Vagli 1": 2660,
    "Zona Vagli 2": 2660,
    "Zona Elettrofiltro": 2660,
    "Zona caldaia Comef": 2660,
    "Zona caldaia Cannon": 2660,
    "Zona caldaie Wanson": 2660,
    "Zona Polverino": 2660,
    "Zona Vagliatura scarti": 3230,
    "Zona Levighe Dieffenbacher": 2945,
    "Zona Levighe Contiroll": 4085,
    "Zona Composad": 4655,
}

ASK_TYPE, ASK_PRIORITY, ASK_LOCATION, ASK_DESCRIPTION, ASK_CONFIRM = range(5)

REQUEST_TYPES = [
    ("Guasto/Anomalia", "guasto_anomalia"),
    ("Pronto intervento", "pronto_intervento"),
    ("Manutenzione", "manutenzione"),
]
REQUEST_TYPE_LABELS = {value: label for label, value in REQUEST_TYPES}

PRIORITIES = [("Bassa", "bassa"), ("Media", "media"), ("Alta", "alta")]
PRIORITY_LABELS = {value: label for label, value in PRIORITIES}

ZONE_GROUPS = {
    "Verde e cippatore": ["Zona Verde", "Zona Cippatore", "Zona Vagliatura scarti"],
    "Essiccatoio e caldaie": [
        "Zona Minibunker", "Zona Pulitori 1", "Zona Pulitori 2", "Zona Vagli 1", "Zona Vagli 2",
        "Zona Essiccatoio", "Zona Elettrofiltro", "Zona caldaia Comef", "Zona caldaia Cannon",
        "Zona caldaie Wanson", "Zona Polverino",
    ],
    "Pressa Dieffenbacher": ["Zona Pressa Dieffenbacher", "Zona Levighe Dieffenbacher", "Zona scarico Dieffenbacher"],
    "Pressa Contiroll": ["Zona Pressa Contiroll", "Zona Levighe Contiroll", "Zona scarico Contiroll"],
    "Altre linee": ["Zona Giben", "Zona Composad"],
    "Linee Melaminici": ["Zona Melaminico 2", "Zona Melaminico 3"],
    "Altro": ["Altro"],
}

if not all([BOT_TOKEN, BOOKSTACK_URL, BOOKSTACK_TOKEN_ID, BOOKSTACK_TOKEN_SECRET]):
    raise RuntimeError("Variabili .env mancanti")


def bookstack_headers():
    return {
        "Authorization": f"Token {BOOKSTACK_TOKEN_ID}:{BOOKSTACK_TOKEN_SECRET}",
        "Content-Type": "application/json",
    }


def italian_day_name(dt):
    return {
        "Monday": "Lunedì",
        "Tuesday": "Martedì",
        "Wednesday": "Mercoledì",
        "Thursday": "Giovedì",
        "Friday": "Venerdì",
        "Saturday": "Sabato",
        "Sunday": "Domenica",
    }[dt.strftime("%A")]


def italian_month_name(dt):
    return {
        1: "Gennaio", 2: "Febbraio", 3: "Marzo", 4: "Aprile", 5: "Maggio", 6: "Giugno",
        7: "Luglio", 8: "Agosto", 9: "Settembre", 10: "Ottobre", 11: "Novembre", 12: "Dicembre",
    }[dt.month]


def bookstack_reference_datetime(dt=None):
    dt = dt or datetime.now()
    return dt - timedelta(days=1) if 0 <= dt.hour < 4 else dt


def current_chapter_name(dt=None):
    ref_dt = bookstack_reference_datetime(dt)
    return f"{italian_month_name(ref_dt)} {ref_dt.year}"


def today_page_name(dt=None):
    ref_dt = bookstack_reference_datetime(dt)
    return f"Data: {italian_day_name(ref_dt)} {ref_dt.strftime('%d-%m-%Y')}"


def get_current_turno(dt=None):
    dt = dt or datetime.now()
    return "Mattina" if 4 <= dt.hour < 12 else "Pomeriggio" if 12 <= dt.hour < 20 else "Notte"


def build_type_keyboard():
    rows = [[InlineKeyboardButton(label, callback_data=f"tipo:{value}")] for label, value in REQUEST_TYPES]
    rows.append([InlineKeyboardButton("Annulla", callback_data="cancel")])
    return InlineKeyboardMarkup(rows)


def build_priority_keyboard():
    rows = [[InlineKeyboardButton(label, callback_data=f"prio:{value}")] for label, value in PRIORITIES]
    rows.append([InlineKeyboardButton("Annulla", callback_data="cancel")])
    return InlineKeyboardMarkup(rows)


def build_zone_group_keyboard():
    rows = [[InlineKeyboardButton(group, callback_data=f"group:{group}")] for group in ZONE_GROUPS.keys()]
    rows.append([InlineKeyboardButton("Annulla", callback_data="cancel")])
    return InlineKeyboardMarkup(rows)


def build_zone_keyboard(group_name):
    rows = [[InlineKeyboardButton(zone, callback_data=f"zona:{zone}")] for zone in ZONE_GROUPS[group_name]]
    rows.append([InlineKeyboardButton("Indietro", callback_data="back_groups")])
    rows.append([InlineKeyboardButton("Annulla", callback_data="cancel")])
    return InlineKeyboardMarkup(rows)


def build_confirm_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Conferma", callback_data="confirm")],
        [InlineKeyboardButton("Annulla", callback_data="cancel")],
    ])


def build_main_menu_keyboard(role):
    rows = [
        [InlineKeyboardButton("🆕 Segnalazione", callback_data="menu:segnalazione")],
        [InlineKeyboardButton("ℹ️ Stato", callback_data="menu:ping")],
    ]
    if role == "admin":
        rows.append([InlineKeyboardButton("📋 Ticket aperti", callback_data="menu:ticket")])
    rows.append([InlineKeyboardButton("❌ Annulla", callback_data="menu:annulla")])
    return InlineKeyboardMarkup(rows)



async def menu_button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not query:
        return

    await query.answer()
    data = query.data

    if data == "menu:segnalazione":
        return await segnalazione_start(update, context)

    if data == "menu:ping":
        user_id = update.effective_user.id
        role = get_user_role(user_id)
        msg = "Pong ✅\nOra: " + datetime.now().strftime("%d/%m/%Y %H:%M:%S") + "\nPagina: " + today_page_name() + "\nTurno: " + get_current_turno() + "\nRuolo: " + role
        await query.message.reply_text(msg)
        return

    if data == "menu:ticket":
        return await ticket_list_command(update, context)

    if data == "menu:annulla":
        reset_conversation_state(context)
        await query.message.reply_text("Annullato.")
        return

def reset_conversation_state(context):
    context.user_data.clear()


def get_actor_name(source):
    user = getattr(source, "effective_user", None) or getattr(source, "from_user", None) or (
        getattr(source, "message", None) and getattr(source.message, "from_user", None)
    )
    return user.full_name if user else "Utente sconosciuto"


async def get_chapters():
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.get(f"{BOOKSTACK_URL}/api/chapters", headers=bookstack_headers())
    if response.status_code != 200:
        return False, f"Errore capitoli: {response.status_code}"
    return True, response.json().get("data", [])


async def get_chapter_detail(chapter_id):
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.get(f"{BOOKSTACK_URL}/api/chapters/{chapter_id}", headers=bookstack_headers())
    if response.status_code != 200:
        return False, f"Errore capitolo {chapter_id}"
    return True, response.json()


async def find_today_page(book_id, dt=None):
    ok_chapters, chapters_data = await get_chapters()
    if not ok_chapters:
        return False, str(chapters_data)

    target_chapter = current_chapter_name(dt)
    selected_chapter = next(
        (c for c in chapters_data if c.get("book_id") == book_id and c.get("name", "").strip() == target_chapter),
        None,
    )
    if not selected_chapter:
        return False, f"Capitolo '{target_chapter}' non trovato libro {book_id}"

    ok_detail, chapter_detail = await get_chapter_detail(selected_chapter["id"])
    if not ok_detail:
        return False, str(chapter_detail)

    target_page = today_page_name(dt)
    page = next((p for p in chapter_detail.get("pages", []) if p.get("name", "").strip() == target_page), None)
    if not page:
        return False, f"Pagina '{target_page}' non trovata"

    page["chapter_id"] = selected_chapter["id"]
    return True, page


async def get_page_content(page_id):
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.get(f"{BOOKSTACK_URL}/api/pages/{page_id}", headers=bookstack_headers())
    if response.status_code != 200:
        return False, f"Errore pagina {page_id}"
    return True, response.json()


async def update_page_content(page_id, page_name, chapter_id, new_content):
    payload = {"name": page_name}
    payload["html"] = new_content

    if chapter_id:
        payload["chapter_id"] = chapter_id


    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.put(
            f"{BOOKSTACK_URL}/api/pages/{page_id}",
            headers=bookstack_headers(),
            json=payload,
        )

    if response.status_code in (200, 202):
        return True, "Pagina aggiornata"
    return False, f"Errore update: {response.status_code} - {response.text[:300]}"


def esc_html(text):
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def build_event_html(actor_source, description, ticket_type, priority, zone, dt=None):
    ora = (dt or datetime.now()).strftime("%H:%M")
    nome_utente = get_actor_name(actor_source)
    tipo_label = REQUEST_TYPE_LABELS.get(ticket_type, ticket_type)
    prio_label = PRIORITY_LABELS.get(priority, priority)
    details_html = esc_html(description.strip()).replace("\n", "<br>")
    zone_html = esc_html(zone)
    nome_html = esc_html(nome_utente)
    return (
        f"<p><strong>[{ora}] {tipo_label}</strong><br>"
        f"Priorità: {prio_label}<br>"
        f"Zona: {zone_html}<br>"
        f"Dettagli: {details_html}<br>"
        f"Segnalato da: {nome_html}</p>"
    )


def build_event_markdown(actor_source, description, ticket_type, priority, zone, dt=None):
    ora = (dt or datetime.now()).strftime("%H:%M")
    nome_utente = get_actor_name(actor_source)
    tipo_label = REQUEST_TYPE_LABELS.get(ticket_type, ticket_type)
    prio_label = PRIORITY_LABELS.get(priority, priority)
    return (
        f"- [{ora}] {tipo_label}\n"
        f" - Priorità: {prio_label}\n"
        f" - Zona: {zone}\n"
        f" - Dettagli: {description.strip()}\n"
        f" - Segnalato da: {nome_utente}\n"
    )


def merge_eventi_principali(content: str, turno: str, event_html: str, event_markdown: str):
    html_patterns = [
        re.compile(
            rf"(Info turno.*?- Turno:\s*{re.escape(turno)}.*?Eventi principali\s*)(.*?)(\s*Segnalazioni ad Atlas)",
            re.DOTALL | re.IGNORECASE,
        ),
        re.compile(
            rf"(<h2[^>]*>.*?Info turno.*?</h2>.*?Turno:?\s*{re.escape(turno)}.*?<h2[^>]*>.*?Eventi principali.*?</h2>)(.*?)(<h2[^>]*>.*?Segnalazioni ad Atlas.*?</h2>)",
            re.DOTALL | re.IGNORECASE,
        ),
    ]

    for pattern in html_patterns:
        match = pattern.search(content)
        if match:
            body = match.group(2).strip()
            new_body = body + event_html if body and "Nessun evento principale registrato" not in body else event_html
            return content[:match.start(2)] + new_body + content[match.end(2):]

    markdown_patterns = [
        re.compile(
            rf"(## Info turno\s*- Data:.*?\s*- Turno:\s*{re.escape(turno)}\s*.*?## Eventi principali\s*\n)(.*?)(\n## Segnalazioni ad Atlas)",
            re.DOTALL | re.IGNORECASE,
        ),
        re.compile(
            rf"(- Turno:\s*{re.escape(turno)}.*?## Eventi principali\s*\n)(.*?)(\n## Segnalazioni ad Atlas)",
            re.DOTALL | re.IGNORECASE,
        ),
    ]

    for pattern in markdown_patterns:
        match = pattern.search(content)
        if match:
            body = match.group(2).rstrip()
            if body and "Nessun evento principale registrato" not in body:
                new_body = body + "\n" + event_markdown + "\n"
            else:
                new_body = event_markdown + "\n"
            return content[:match.start(2)] + new_body + content[match.end(2):]

    return None


async def append_event_to_bookstack(actor_source, description, ticket_type, priority, zone):
    now = datetime.now()
    book_id = ZONE_TO_BOOK_ID.get(zone, ZONE_TO_BOOK_ID["Altro"])

    found, page_data = await find_today_page(book_id, now)
    if not found:
        return False, str(page_data), 0

    page_id = page_data["id"]
    page_name = page_data["name"]
    chapter_id = page_data.get("chapter_id")

    ok_page, current_page = await get_page_content(page_id)
    if not ok_page:
        return False, str(current_page), page_id

    turno = get_current_turno(now)
    event_html = build_event_html(actor_source, description, ticket_type, priority, zone, now)
    event_markdown = build_event_markdown(actor_source, description, ticket_type, priority, zone, now)

    current_content = current_page.get("markdown") or current_page.get("html") or ""
    updated_content = merge_eventi_principali(current_content, turno, event_html, event_markdown)
    if not updated_content:
        return False, f"Sezione turno '{turno}' non trovata", page_id

    ok_update, message = await update_page_content(page_id, page_name, chapter_id, updated_content)
    if not ok_update:
        return False, message, page_id

    return True, f"Segnalazione inserita nel turno '{turno}' della pagina '{page_name}' (libro {book_id})", page_id


def build_summary_text(context):
    tipo = REQUEST_TYPE_LABELS.get(context.user_data.get("ticket_type"), "-")
    prio = PRIORITY_LABELS.get(context.user_data.get("priority"), "-")
    zona = context.user_data.get("zone", "-")
    descrizione = context.user_data.get("description", "-")
    turno = get_current_turno()
    return (
        f"Controlla i dati:\n\n"
        f"Tipo: {tipo}\n"
        f"Priorità: {prio}\n"
        f"Zona: {zona}\n"
        f"Turno: {turno}\n"
        f"Descrizione:\n{descrizione}\n\n"
        f"Conferma per salvare su BookStack e DB."
    )


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    full_name = update.effective_user.full_name
    username = update.effective_user.username
    get_or_create_user(user_id, full_name, username)
    role = get_user_role(user_id)

    text = (
        "Bot Manutenzione\n"
        "/start - menu\n"
        "/ping - stato\n"
        "/segnalazione - nuova segnalazione\n"
        "/ticket - ticket aperti admin\n"
        "/annulla - annulla\n"
        f"Ruolo: {role}"
    )

    await update.message.reply_text(text)

async def ping_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    role = get_user_role(user_id)
    await update.message.reply_text(
        f"Pong ✅\n"
        f"Ora: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n"
        f"Pagina: {today_page_name()}\n"
        f"Turno: {get_current_turno()}\n"
        f"Ruolo: {role}"
    )


async def ticket_list_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    role = get_user_role(user_id)
    if role != "admin":
        await update.message.reply_text("Solo admin.")
        return

    tickets = get_open_tickets(15)
    if not tickets:
        await update.message.reply_text("Nessun ticket aperto.")
        return

    testo = "TICKET APERTI (15 più recenti)\n\n"
    for i, (ticket_id, issue_type, priority, location, status, created_at) in enumerate(tickets, 1):
        emoji = "🔴" if priority == "alta" else "🟠" if priority == "media" else "🟢"
        testo += f"{i}. {ticket_id}\n{emoji} {issue_type} | {priority} | {location}\n{created_at}\n\n"
    await update.message.reply_text(testo)


async def segnalazione_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reset_conversation_state(context)
    await (update.message or update.callback_query.message).reply_text("Nuova segnalazione: scegli il tipo", reply_markup=build_type_keyboard())
    return ASK_TYPE


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data or ""

    if data == "cancel":
        reset_conversation_state(context)
        await query.message.reply_text("Annullato. Usa /segnalazione per ricominciare.")
        try:
            await query.edit_message_reply_markup(reply_markup=None)
        except Exception:
            pass
        return ConversationHandler.END

    if data == "confirm":
        description = context.user_data.get("description")
        ticket_type = context.user_data.get("ticket_type")
        priority = context.user_data.get("priority")
        zone = context.user_data.get("zone")

        if not all([description, ticket_type, priority, zone]):
            reset_conversation_state(context)
            await query.message.reply_text("Dati incompleti. Usa /segnalazione")
            return ConversationHandler.END

        user_id = query.from_user.id
        full_name = query.from_user.full_name
        get_or_create_user(user_id, full_name, query.from_user.username)

        tipo_label = REQUEST_TYPE_LABELS.get(ticket_type, ticket_type)
        await query.edit_message_text("Salvo su BookStack e DB...")

        ok_bookstack, bookstack_msg, page_id = await append_event_to_bookstack(
            query, description, ticket_type, priority, zone
        )

        if ok_bookstack:
            ticket_id = create_ticket(
                user_id,
                ticket_type,
                priority,
                zone,
                description,
                get_current_turno(),
                page_id,
            )
            emoji = "🔴" if priority == "alta" else "🟠" if priority == "media" else "🟢"
            await query.message.reply_text(
                f"{emoji} {tipo_label.upper()} CREATO!\n\n"
                f"ID: {ticket_id}\n"
                f"Zona: {zone}\n"
                f"Priorità: {PRIORITY_LABELS[priority].upper()}\n"
                f"BookStack: {bookstack_msg}"
            )
        else:
            await query.message.reply_text(f"❌ BookStack fallito: {bookstack_msg}\nTicket locale NON creato.")

        reset_conversation_state(context)
        return ConversationHandler.END

    if data.startswith("tipo:"):
        context.user_data["ticket_type"] = data.split(":", 1)[1]
        await query.edit_message_text("Priorità:", reply_markup=build_priority_keyboard())
        return ASK_PRIORITY

    if data.startswith("prio:"):
        context.user_data["priority"] = data.split(":", 1)[1]
        await query.edit_message_text("Gruppo zona:", reply_markup=build_zone_group_keyboard())
        return ASK_LOCATION

    if data == "back_groups":
        await query.edit_message_text("Gruppo zona:", reply_markup=build_zone_group_keyboard())
        return ASK_LOCATION

    if data.startswith("group:"):
        context.user_data["zone_group"] = data.split(":", 1)[1]
        await query.edit_message_text(
            f"{context.user_data['zone_group']}:",
            reply_markup=build_zone_keyboard(context.user_data["zone_group"]),
        )
        return ASK_LOCATION

    if data.startswith("zona:"):
        context.user_data["zone"] = data.split(":", 1)[1]
        tipo = REQUEST_TYPE_LABELS.get(context.user_data.get("ticket_type"), "-")
        prio = PRIORITY_LABELS.get(context.user_data.get("priority"), "-")
        zona = context.user_data.get("zone", "-")
        await query.edit_message_text(
            f"Riepilogo:\n\nTipo: {tipo}\nPriorità: {prio}\nZona: {zona}\n\nOra scrivi la descrizione."
        )
        return ASK_DESCRIPTION

    reset_conversation_state(context)
    await query.message.reply_text("Comando non riconosciuto. Usa /segnalazione")
    return ConversationHandler.END


async def segnalazione_receive(update: Update, context: ContextTypes.DEFAULT_TYPE):
    description = (update.message.text or "").strip()
    if not description:
        await update.message.reply_text("Testo vuoto. Riscrivi.")
        return ASK_DESCRIPTION

    if not all(context.user_data.get(x) for x in ["ticket_type", "priority", "zone"]):
        reset_conversation_state(context)
        await update.message.reply_text("Dati incompleti. Usa /segnalazione")
        return ConversationHandler.END

    context.user_data["description"] = description
    await update.message.reply_text(build_summary_text(context), reply_markup=build_confirm_keyboard())
    return ASK_CONFIRM


async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reset_conversation_state(context)
    await update.message.reply_text("Annullato. Usa /segnalazione")
    return ConversationHandler.END


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.exception("Errore", exc_info=context.error)


def main():
    init_db()
    logger.info("Avvio bot manutenzione...")
    application = Application.builder().token(BOT_TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("segnalazione", segnalazione_start)],
        states={
            ASK_TYPE: [CallbackQueryHandler(button_handler)],
            ASK_PRIORITY: [CallbackQueryHandler(button_handler)],
            ASK_LOCATION: [CallbackQueryHandler(button_handler)],
            ASK_DESCRIPTION: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, segnalazione_receive),
                CallbackQueryHandler(button_handler),
            ],
            ASK_CONFIRM: [CallbackQueryHandler(button_handler)],
        },
        fallbacks=[CommandHandler("annulla", cancel_command)],
        allow_reentry=True,
    )

    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("ping", ping_command))
    application.add_handler(CommandHandler("ticket", ticket_list_command))
    application.add_handler(CommandHandler("annulla", cancel_command))
    application.add_handler(CallbackQueryHandler(menu_button_handler, pattern=r"^menu:"))
    application.add_handler(conv_handler)
    application.add_error_handler(error_handler)

    logger.info("Bot pronto per produzione!")
    application.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
